package com.example.insurance.repository;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.example.insurance.entity.Admin;

@DataJpaTest
class AdminRepositoryTest {

    @Autowired
    private AdminRepository adminRepository;

    @Test
    void testSaveAdmin() {
        // Create a new Admin object
        Admin admin = new Admin();
        admin.setName("admin_test");
        admin.setUsername("adminuser");
        admin.setEmail("admin@test.com");
        admin.setPassword("admin123");

        // Save Admin to DB
        Admin savedAdmin = adminRepository.save(admin);

        // Assertions
        assertNotNull(savedAdmin.getAdminId(), "Admin ID should be generated");
        assertEquals("admin_test", savedAdmin.getName(), "Name should match");
        assertEquals("adminuser", savedAdmin.getUsername(), "Username should match");
        assertEquals("admin@test.com", savedAdmin.getEmail(), "Email should match");
    }

    @Test
    void testFindAdminById() {
        // Create and save Admin
        Admin admin = new Admin();
        admin.setName("admin_find");
        admin.setUsername("finduser");
        admin.setEmail("find@test.com");
        admin.setPassword("find123");

        Admin savedAdmin = adminRepository.save(admin);

        // Find by ID
        Optional<Admin> foundAdmin = adminRepository.findById(savedAdmin.getAdminId());

        // Assertions
        assertTrue(foundAdmin.isPresent(), "Admin should be found");
        assertEquals("admin_find", foundAdmin.get().getName());
        assertEquals("finduser", foundAdmin.get().getUsername());
        assertEquals("find@test.com", foundAdmin.get().getEmail());
    }
}

