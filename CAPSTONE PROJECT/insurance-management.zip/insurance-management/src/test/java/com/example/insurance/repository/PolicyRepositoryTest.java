package com.example.insurance.repository;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.insurance.entity.Policy;

@SpringBootTest
class PolicyRepositoryTest {

    @Autowired
    private PolicyRepository policyRepository;

    @Test
    void testSavePolicy() {
        Policy policy = new Policy();
        policy.setPolicyName("Health Insurance");
        policy.setPremiumAmount(5000.0);
        policy.setStatus("Active");
        policy.setDuration("1 Year");

        Policy savedPolicy = policyRepository.save(policy);

        assertNotNull(savedPolicy.getPolicyId(), "Policy ID should be generated");
        assertEquals("Health Insurance", savedPolicy.getPolicyName());
        assertEquals(5000.0, savedPolicy.getPremiumAmount());
        assertEquals("Active", savedPolicy.getStatus());
        assertEquals("1 Year", savedPolicy.getDuration());
    }

    @Test
    void testFindPolicyById() {
        Policy policy = new Policy();
        policy.setPolicyName("Vehicle Insurance");
        policy.setPremiumAmount(7000.0);
        policy.setStatus("Active");
        policy.setDuration("2 Years");

        Policy savedPolicy = policyRepository.save(policy);

        Optional<Policy> foundPolicy = policyRepository.findById(savedPolicy.getPolicyId());

        assertTrue(foundPolicy.isPresent(), "Policy should be found");
        assertEquals("Vehicle Insurance", foundPolicy.get().getPolicyName());
        assertEquals(7000.0, foundPolicy.get().getPremiumAmount());
        assertEquals("Active", foundPolicy.get().getStatus());
        assertEquals("2 Years", foundPolicy.get().getDuration());
    }
}
