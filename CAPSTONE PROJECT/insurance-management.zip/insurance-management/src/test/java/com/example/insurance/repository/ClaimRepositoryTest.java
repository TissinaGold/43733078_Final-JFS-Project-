package com.example.insurance.repository;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.example.insurance.entity.Claim;

@DataJpaTest
class ClaimRepositoryTest {

    @Autowired
    private ClaimRepository claimRepository;

    @Test
    void testSaveClaim() {
        Claim claim = new Claim();
        claim.setPolicyId(1L);
        claim.setClaimAmount(10000.0);
        claim.setDescription("Accident claim");
        claim.setStatus("Pending");

        Claim savedClaim = claimRepository.save(claim);

        assertNotNull(savedClaim.getClaimId(), "Claim ID should be generated");
        assertEquals(1L, savedClaim.getPolicyId());
        assertEquals(10000.0, savedClaim.getClaimAmount());
        assertEquals("Accident claim", savedClaim.getDescription());
        assertEquals("Pending", savedClaim.getStatus());
    }

    @Test
    void testFindClaimById() {
        Claim claim = new Claim();
        claim.setPolicyId(2L);
        claim.setClaimAmount(5000.0);
        claim.setDescription("Health claim");
        claim.setStatus("Pending");

        Claim savedClaim = claimRepository.save(claim);

        Optional<Claim> foundClaim = claimRepository.findById(savedClaim.getClaimId());

        assertTrue(foundClaim.isPresent(), "Claim should be found");
        assertEquals(2L, foundClaim.get().getPolicyId());
        assertEquals(5000.0, foundClaim.get().getClaimAmount());
        assertEquals("Health claim", foundClaim.get().getDescription());
        assertEquals("Pending", foundClaim.get().getStatus());
    }
}
