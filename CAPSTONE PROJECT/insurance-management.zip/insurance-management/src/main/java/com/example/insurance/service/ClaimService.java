package com.example.insurance.service;

import java.util.List;

import com.example.insurance.entity.Claim;

public interface ClaimService {

    List<Claim> getAllClaims();

    Claim saveClaim(Claim claim);

    void deleteClaim(Long id);
}
