package com.example.insurance.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.insurance.entity.Policy;
import com.example.insurance.repository.PolicyRepository;

@Service
public class PolicyServiceImpl implements PolicyService {

    private final PolicyRepository policyRepository;

    public PolicyServiceImpl(PolicyRepository policyRepository) {
        this.policyRepository = policyRepository;
    }

    @Override
    public List<Policy> getAllPolicies() {
        return policyRepository.findAll();
    }

    @Override
    public Policy savePolicy(Policy policy) {
        return policyRepository.save(policy); // DB INSERT/UPDATE
    }

    @Override
    public void deletePolicy(Long id) {
        policyRepository.deleteById(id);
    }
}
