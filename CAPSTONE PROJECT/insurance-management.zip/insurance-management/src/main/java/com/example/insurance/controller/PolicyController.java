package com.example.insurance.controller;

import java.util.List;

import org.springframework.web.bind.annotation.*;

import com.example.insurance.entity.Policy;
import com.example.insurance.service.PolicyService;

@RestController
@RequestMapping("/api/policies")
@CrossOrigin(origins = "*")
public class PolicyController {

    private final PolicyService policyService;

    public PolicyController(PolicyService policyService) {
        this.policyService = policyService;
    }

    @GetMapping
    public List<Policy> getAllPolicies() {
        return policyService.getAllPolicies();
    }

    @PostMapping
    public Policy addPolicy(@RequestBody Policy policy) {
        return policyService.savePolicy(policy);
    }

    @DeleteMapping("/{id}")
    public void deletePolicy(@PathVariable Long id) {
        policyService.deletePolicy(id);
    }
}
