package com.example.insurance.service;

import java.util.List;

import com.example.insurance.entity.Policy;

public interface PolicyService {

    List<Policy> getAllPolicies();

    Policy savePolicy(Policy policy);

    void deletePolicy(Long id);
}
