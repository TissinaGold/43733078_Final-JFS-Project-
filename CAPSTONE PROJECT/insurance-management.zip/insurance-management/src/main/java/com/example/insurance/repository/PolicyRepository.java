package com.example.insurance.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.insurance.entity.Policy;

@Repository
public interface PolicyRepository extends JpaRepository<Policy, Long> {
    // No additional methods needed for basic CRUD
}
