package com.example.insurance.service;

import java.util.List;

import com.example.insurance.entity.Admin;

public interface AdminService {

    List<Admin> getAllAdmins();

    Admin saveAdmin(Admin admin);

    void deleteAdmin(Long id);
}
