package com.example.insurance.controller;

import java.util.List;

import org.springframework.web.bind.annotation.*;

import com.example.insurance.entity.Claim;
import com.example.insurance.service.ClaimService;

@RestController
@RequestMapping("/api/claims")
@CrossOrigin(origins = "*")
public class ClaimController {

    private final ClaimService claimService;

    public ClaimController(ClaimService claimService) {
        this.claimService = claimService;
    }

    @GetMapping
    public List<Claim> getAllClaims() {
        return claimService.getAllClaims();
    }

    @PostMapping
    public Claim addClaim(@RequestBody Claim claim) {
        return claimService.saveClaim(claim);
    }

    @DeleteMapping("/{id}")
    public void deleteClaim(@PathVariable Long id) {
        claimService.deleteClaim(id);
    }
}
