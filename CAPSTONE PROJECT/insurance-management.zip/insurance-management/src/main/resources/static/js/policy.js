const API = "http://localhost:8080/api/policies";

async function addPolicy() {
    const policy = {
        policyName: document.getElementById("policyName").value,
        premiumAmount: document.getElementById("premiumAmount").value,
        status: document.getElementById("status").value,
        duration: document.getElementById("duration").value,
        name: document.getElementById("name").value,
        premium: document.getElementById("premium").value
    };

    const res = await fetch(API, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(policy)
    });

    if (res.ok) {
        loadPolicies();
    }
}

async function loadPolicies() {
    const res = await fetch(API);
    const data = await res.json();

    const tbody = document.getElementById("policyTableBody");
    tbody.innerHTML = "";

    data.forEach((p, i) => {
        tbody.innerHTML += `
            <tr>
                <td>${i + 1}</td>
                <td>${p.policyName}</td>
                <td>${p.premiumAmount}</td>
                <td>${p.status}</td>
                <td>${p.duration}</td>
                <td>${p.name}</td>
                <td>${p.premium}</td>
            </tr>`;
    });
}

window.onload = loadPolicies;
