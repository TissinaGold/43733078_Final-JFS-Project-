const API = "http://localhost:8080/api/claims";

async function addClaim() {
    const claim = {
        claimAmount: document.getElementById("claimAmount").value,
        policyId: document.getElementById("policyId").value,
        status: document.getElementById("status").value,
        description: document.getElementById("description").value
    };

    const response = await fetch(API, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(claim)
    });

    if (response.ok) {
        loadClaims();
    }
}

async function loadClaims() {
    const response = await fetch(API);
    const claims = await response.json();

    const tbody = document.getElementById("claimTableBody");
    tbody.innerHTML = "";

    claims.forEach((c, i) => {
        tbody.innerHTML += `
            <tr>
                <td>${i + 1}</td>
                <td>${c.claimAmount}</td>
                <td>${c.policyId}</td>
                <td>${c.status}</td>
                <td>${c.description}</td>
            </tr>
        `;
    });
}

window.onload = loadClaims;
