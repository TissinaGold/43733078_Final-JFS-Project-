const API = "http://localhost:8080/api/admins";

async function addAdmin() {
    const admin = {
        username: document.getElementById("username").value,
        password: document.getElementById("password").value,
        email: document.getElementById("email").value,
        name: document.getElementById("name").value
    };

    const response = await fetch(API, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(admin)
    });

    if (response.ok) {
        loadAdmins();
    }
}

async function loadAdmins() {
    const response = await fetch(API);
    const admins = await response.json();

    const tbody = document.getElementById("adminTableBody");
    tbody.innerHTML = "";

    admins.forEach((a, i) => {
        tbody.innerHTML += `
            <tr>
                <td>${i + 1}</td>
                <td>${a.username}</td>
                <td>${a.email}</td>
                <td>${a.name}</td>
            </tr>
        `;
    });
}

window.onload = loadAdmins;
