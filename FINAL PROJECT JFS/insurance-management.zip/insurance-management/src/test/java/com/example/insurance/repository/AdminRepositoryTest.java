package com.example.insurance.repository;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.example.insurance.entity.Admin;

@DataJpaTest
class AdminRepositoryTest {

    @Autowired
    private AdminRepository adminRepository;

    @Test
    void testSaveAdmin() {
        Admin admin = new Admin();
        admin.setUsername("admin_test");
        admin.setPassword("admin123");
        admin.setEmail("admin@test.com");

        Admin savedAdmin = adminRepository.save(admin);

        assertNotNull(savedAdmin.getAdminId());
        assertEquals("admin_test", savedAdmin.getUsername());
    }

    @Test
    void testFindAdminById() {
        Admin admin = new Admin();
        admin.setUsername("admin_find");
        admin.setPassword("password");
        admin.setEmail("find@test.com");

        Admin savedAdmin = adminRepository.save(admin);

        Optional<Admin> foundAdmin = adminRepository.findById(savedAdmin.getAdminId());

        assertTrue(foundAdmin.isPresent());
        assertEquals("admin_find", foundAdmin.get().getUsername());
    }
}
