package com.example.insurance.repository;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.insurance.entity.Policy;

@SpringBootTest
class PolicyRepositoryTest {

    @Autowired
    private PolicyRepository policyRepository;

    @Test
    void testSavePolicy() {
        Policy policy = new Policy();
        policy.setPolicyName("Health Insurance");
        policy.setPolicyType("Health");
        policy.setPremiumAmount(5000);
        policy.setDurationInYears(2);

        Policy savedPolicy = policyRepository.save(policy);

        assertNotNull(savedPolicy.getPolicyId());
        assertEquals("Health Insurance", savedPolicy.getPolicyName());
    }

    @Test
    void testFindPolicyById() {
        Policy policy = new Policy();
        policy.setPolicyName("Life Insurance");
        policy.setPolicyType("Life");
        policy.setPremiumAmount(10000);
        policy.setDurationInYears(5);

        Policy savedPolicy = policyRepository.save(policy);

        Policy foundPolicy =
                policyRepository.findById(savedPolicy.getPolicyId()).orElse(null);

        assertNotNull(foundPolicy);
        assertEquals("Life Insurance", foundPolicy.getPolicyName());
    }
}
