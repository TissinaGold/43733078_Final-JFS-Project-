package com.example.insurance.repository;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.example.insurance.entity.Claim;

@DataJpaTest
class ClaimRepositoryTest {

    @Autowired
    private ClaimRepository claimRepository;

    @Test
    void testSaveClaim() {
        Claim claim = new Claim();
        claim.setClaimAmount(10000);
        claim.setClaimStatus("APPROVED");

        Claim savedClaim = claimRepository.save(claim);

        assertNotNull(savedClaim.getClaimId());
        assertEquals("APPROVED", savedClaim.getClaimStatus());
    }

    @Test
    void testFindClaimById() {
        Claim claim = new Claim();
        claim.setClaimAmount(5000);
        claim.setClaimStatus("PENDING");

        Claim savedClaim = claimRepository.save(claim);

        Optional<Claim> foundClaim = claimRepository.findById(savedClaim.getClaimId());

        assertTrue(foundClaim.isPresent());
        assertEquals("PENDING", foundClaim.get().getClaimStatus());
    }
}
