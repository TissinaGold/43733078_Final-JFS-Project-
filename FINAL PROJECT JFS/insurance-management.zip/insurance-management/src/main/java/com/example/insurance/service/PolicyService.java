package com.example.insurance.service;

import java.util.List;
import com.example.insurance.entity.Policy;

public interface PolicyService {
    Policy createPolicy(Policy policy);
    List<Policy> getAllPolicies();
    Policy getPolicyById(Long id);
    void deletePolicy(Long id);
}
