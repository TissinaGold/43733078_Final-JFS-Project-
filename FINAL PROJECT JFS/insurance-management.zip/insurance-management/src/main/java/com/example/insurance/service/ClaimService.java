package com.example.insurance.service;

import java.util.List;
import com.example.insurance.entity.Claim;

public interface ClaimService {
    Claim createClaim(Claim claim);
    List<Claim> getAllClaims();
    Claim getClaimById(Long id);
    void deleteClaim(Long id);
}

