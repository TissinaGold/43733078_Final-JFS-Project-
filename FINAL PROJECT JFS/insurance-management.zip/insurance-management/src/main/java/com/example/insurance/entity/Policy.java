package com.example.insurance.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "policies")
public class Policy {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long policyId;

    private String policyName;
    private String policyType;
    private double premiumAmount;
    private int durationInYears;

    // Constructors
    public Policy() {}

    public Policy(String policyName, String policyType, double premiumAmount, int durationInYears) {
        this.policyName = policyName;
        this.policyType = policyType;
        this.premiumAmount = premiumAmount;
        this.durationInYears = durationInYears;
    }

    // Getters and Setters
    public Long getPolicyId() { return policyId; }
    public void setPolicyId(Long policyId) { this.policyId = policyId; }

    public String getPolicyName() { return policyName; }
    public void setPolicyName(String policyName) { this.policyName = policyName; }

    public String getPolicyType() { return policyType; }
    public void setPolicyType(String policyType) { this.policyType = policyType; }

    public double getPremiumAmount() { return premiumAmount; }
    public void setPremiumAmount(double premiumAmount) { this.premiumAmount = premiumAmount; }

    public int getDurationInYears() { return durationInYears; }
    public void setDurationInYears(int durationInYears) { this.durationInYears = durationInYears; }
}
